EDUGE · Paquete de aplicación web instalable (PWA)
==================================================

Contenido
---------
index.html              La aplicación completa (un solo archivo).
manifest.webmanifest    Identidad de la app: nombre, colores, iconos, atajos.
sw.js                   Service worker: permite abrirla sin conexión.
instalar.html           Página con instrucciones de instalación.
icons/                  Iconos 192, 512, maskable y Apple Touch.

Cómo publicarla (5 minutos, gratis)
-----------------------------------
Opción A · Netlify Drop
  1. Entra en https://app.netlify.com/drop
  2. Arrastra esta carpeta completa.
  3. Te dará una dirección tipo https://eduge.netlify.app
  4. Abre esa dirección en el móvil e instálala.

Opción B · Vercel
  1. Crea una cuenta en https://vercel.com
  2. "Add New… → Project → Deploy" y sube la carpeta (o conecta un repositorio).

Opción C · GitHub Pages
  1. Crea un repositorio y sube los archivos.
  2. Settings → Pages → Branch: main / root.
  3. La dirección será https://usuario.github.io/repositorio/

Opción D · Dominio propio (recomendado para el Ministerio o el centro)
  1. Contrata un dominio, por ejemplo eduge.ga.
  2. Sube esta carpeta al hosting del dominio.
  3. Activa HTTPS (certificado gratuito Let's Encrypt).

Requisitos importantes
----------------------
· La instalación como app necesita HTTPS (o localhost). Abrir el archivo
  con doble clic (file://) no permite instalar.
· Los datos de esta versión se guardan en el navegador del dispositivo.
  Para uso real con varios usuarios hace falta conectar la base de datos
  (Supabase/Firebase o servidor propio), como se explica en el manual.

Instalación en los dispositivos
-------------------------------
Android/Chrome: menú ⋮ → Instalar aplicación.
iPhone/iPad:    Safari → Compartir → Añadir a pantalla de inicio.
Windows/Mac:    icono de instalar en la barra de direcciones.

EDUGE · Educación en Guinea Ecuatorial
Titular: Angelín Masa Makina Nchama · Ecobank 39360021151
